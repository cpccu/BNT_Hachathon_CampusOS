-- ============================================================================
-- CampusOS shared data table  (run AFTER supabase/schema.sql, in SQL Editor)
-- One generic table keeps events, RSVPs, lost & found, complaints and
-- resources shared between all users with no extra migrations.
-- NOTE: policies are open for hackathon demo purposes. See README "Security".
-- ============================================================================
create table if not exists public.campus_items (
  collection text not null,
  id         text not null,
  data       jsonb not null,
  created_at timestamptz not null default now(),
  primary key (collection, id)
);
create index if not exists idx_campus_items_collection on public.campus_items(collection, created_at desc);

alter table public.campus_items enable row level security;

drop policy if exists "campus_items read"   on public.campus_items;
drop policy if exists "campus_items insert" on public.campus_items;
drop policy if exists "campus_items update" on public.campus_items;
drop policy if exists "campus_items delete" on public.campus_items;

create policy "campus_items read"   on public.campus_items for select to anon, authenticated using (true);
create policy "campus_items insert" on public.campus_items for insert to anon, authenticated with check (true);
create policy "campus_items update" on public.campus_items for update to anon, authenticated using (true) with check (true);
create policy "campus_items delete" on public.campus_items for delete to anon, authenticated using (true);

-- Auth profile table (from schema.sql) must let the signup trigger + client upsert work:
-- if you hit "new row violates row-level security" on sign up, run:
--   create policy "users insert own" on public.users for insert to authenticated with check (auth.uid() = id);
