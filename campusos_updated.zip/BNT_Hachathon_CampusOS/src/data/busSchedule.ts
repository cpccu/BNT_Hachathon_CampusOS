/**
 * Shuttle timetable (departures from Main Campus).
 * Keep in sync with the Helpdesk knowledge base in src/app/api/chat/route.ts.
 * >>> Replace with the official transport office timetable before the demo. <<<
 */
export interface BusRoute {
  id: string;
  name: string;
  destination: string;
  stops: string[];
  departures: string[]; // 24h "HH:MM", from campus
  color: string; // tailwind gradient classes
}

/** Weekdays with no bus service (0 = Sunday ... 6 = Saturday). Empty = runs daily. */
export const BUS_OFF_DAYS: number[] = [];

export const BUS_ROUTES: BusRoute[] = [
  {
    id: "A",
    name: "Route A",
    destination: "Mirpur",
    stops: ["Main Campus", "Savar Bus Stand", "Gabtoli", "Mirpur 10"],
    departures: ["07:00", "09:00", "12:00", "17:00", "20:00"],
    color: "from-campus-600 to-campus-800",
  },
  {
    id: "B",
    name: "Route B",
    destination: "Gulshan",
    stops: ["Main Campus", "Savar Bus Stand", "Mohakhali", "Gulshan 1"],
    departures: ["08:00", "13:00", "18:00"],
    color: "from-emerald-600 to-emerald-800",
  },
  {
    id: "C",
    name: "Route C",
    destination: "Uttara",
    stops: ["Main Campus", "Savar Bus Stand", "Airport Road", "Uttara Sector 3"],
    departures: ["07:30", "14:00", "19:00"],
    color: "from-violet-600 to-violet-800",
  },
];
