"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { ScanLine, CheckCircle2, XCircle, AlertTriangle, Camera, CameraOff, Users, RefreshCw } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { listItems, listMerged, upsertItem } from "@/lib/shared";
import { MOCK_EVENTS, CampusEvent } from "@/data/mockData";

type Rsvp = {
  id: string;
  eventId: string;
  studentId: string;
  studentName: string;
  ticketId: string;
  status: "confirmed" | "checked_in" | "cancelled";
  checkedInAt?: string;
};

type Result =
  | { kind: "ok"; rsvp: Rsvp; eventTitle: string }
  | { kind: "dup"; rsvp: Rsvp; eventTitle: string }
  | { kind: "bad"; message: string };

/** The ticket QR holds JSON (see QrTicketModal). Accept that, or a plain ticket code typed by hand. */
function parseTicket(raw: string): { ticketId?: string; eventId?: string; studentId?: string } {
  const text = raw.trim();
  try {
    const j = JSON.parse(text);
    if (j && j.ticketId) return { ticketId: j.ticketId, eventId: j.eventId, studentId: j.studentId };
  } catch {}
  return { ticketId: text };
}

export default function CheckInPage() {
  const { user, loading } = useAuth();
  const [events, setEvents] = useState<CampusEvent[]>([]);
  const [rsvps, setRsvps] = useState<Rsvp[]>([]);
  const [eventId, setEventId] = useState<string>("");
  const [manual, setManual] = useState("");
  const [result, setResult] = useState<Result | null>(null);
  const [scanning, setScanning] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const scannerRef = useRef<any>(null);
  const lastScan = useRef<{ text: string; at: number }>({ text: "", at: 0 });
  const rsvpsRef = useRef<Rsvp[]>([]);
  rsvpsRef.current = rsvps;

  const refresh = useCallback(async () => {
    const [evts, rs] = await Promise.all([
      listMerged<CampusEvent>("events", MOCK_EVENTS),
      listItems<Rsvp>("rsvps"),
    ]);
    setEvents(evts);
    setRsvps(rs);
    setEventId((cur) => cur || evts[0]?.id || "");
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const canScan = user && (user.role === "club_admin" || user.role === "admin");

  const verify = useCallback(
    async (raw: string) => {
      const t = parseTicket(raw);
      // Always re-read from the shared store so two scanners never double-admit a ticket
      const fresh = await listItems<Rsvp>("rsvps");
      setRsvps(fresh);
      const match = fresh.find(
        (r) =>
          r.status !== "cancelled" &&
          (r.ticketId === t.ticketId || (t.eventId && t.studentId && r.id === `${t.eventId}__${t.studentId}`))
      );
      if (!match) {
        setResult({ kind: "bad", message: "No registration found for this ticket." });
        return;
      }
      const evt = events.find((e) => e.id === match.eventId);
      const eventTitle = evt?.title || match.eventId;
      if (eventId && match.eventId !== eventId) {
        setResult({ kind: "bad", message: `This ticket is for “${eventTitle}”, not the selected event.` });
        return;
      }
      if (match.status === "checked_in") {
        setResult({ kind: "dup", rsvp: match, eventTitle });
        return;
      }
      const updated: Rsvp = { ...match, status: "checked_in", checkedInAt: new Date().toISOString() };
      await upsertItem("rsvps", match.id, updated);
      setRsvps((prev) => prev.map((r) => (r.id === match.id ? updated : r)));
      setResult({ kind: "ok", rsvp: updated, eventTitle });
    },
    [events, eventId]
  );

  // Camera scanner
  useEffect(() => {
    if (!scanning || !canScan) return;
    let cancelled = false;
    (async () => {
      try {
        const { Html5Qrcode } = await import("html5-qrcode");
        const qr = new Html5Qrcode("qr-reader");
        scannerRef.current = qr;
        await qr.start(
          { facingMode: "environment" },
          { fps: 10, qrbox: { width: 240, height: 240 } },
          (text: string) => {
            const nowMs = Date.now();
            if (text === lastScan.current.text && nowMs - lastScan.current.at < 3000) return;
            lastScan.current = { text, at: nowMs };
            verify(text);
          },
          () => {}
        );
        if (cancelled) await qr.stop();
      } catch (e: any) {
        setCameraError("Camera unavailable. Allow camera access, or type the ticket code below.");
        setScanning(false);
      }
    })();
    return () => {
      cancelled = true;
      const qr = scannerRef.current;
      if (qr) {
        qr.stop().then(() => qr.clear()).catch(() => {});
        scannerRef.current = null;
      }
    };
  }, [scanning, canScan, verify]);

  if (loading) return null;

  if (!canScan) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center space-y-3">
        <ScanLine className="w-10 h-10 mx-auto text-campus-600" />
        <h1 className="text-xl font-black text-slate-900 dark:text-white">Check-in is for club leads and admins</h1>
        <p className="text-sm text-slate-500">
          Sign in as a club lead or admin to scan student tickets at the door.
        </p>
        <Link href="/login" className="inline-block px-4 py-2 rounded-xl bg-campus-600 text-white font-bold text-sm">
          Sign in
        </Link>
      </div>
    );
  }

  const forEvent = rsvps.filter((r) => r.eventId === eventId && r.status !== "cancelled");
  const checkedIn = forEvent.filter((r) => r.status === "checked_in");

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8 space-y-5">
      <header>
        <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900 dark:text-white flex items-center gap-2">
          <ScanLine className="w-7 h-7 text-campus-600" /> Event check-in
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          Scan a student&apos;s QR ticket at the door. Each ticket works once.
        </p>
      </header>

      <label className="block">
        <span className="text-xs font-bold text-slate-600 dark:text-slate-300">Event at this door</span>
        <select
          value={eventId}
          onChange={(e) => {
            setEventId(e.target.value);
            setResult(null);
          }}
          className="mt-1 w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2.5 text-sm"
        >
          {events.map((e) => (
            <option key={e.id} value={e.id}>
              {e.title} · {e.date}
            </option>
          ))}
        </select>
      </label>

      <div className="grid grid-cols-2 gap-3">
        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4">
          <div className="text-xs text-slate-500 flex items-center gap-1"><Users className="w-3.5 h-3.5" /> Registered</div>
          <div className="text-3xl font-black text-slate-900 dark:text-white">{forEvent.length}</div>
        </div>
        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4">
          <div className="text-xs text-slate-500 flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5" /> Checked in</div>
          <div className="text-3xl font-black text-emerald-600">{checkedIn.length}</div>
        </div>
      </div>

      {/* Scanner */}
      <section className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 space-y-3">
        <div id="qr-reader" className={scanning ? "w-full overflow-hidden rounded-2xl" : "hidden"} />
        <button
          onClick={() => {
            setCameraError(null);
            setScanning((s) => !s);
          }}
          className="w-full py-3 rounded-xl bg-campus-600 hover:bg-campus-700 text-white font-bold text-sm flex items-center justify-center gap-2"
        >
          {scanning ? <><CameraOff className="w-4 h-4" /> Stop camera</> : <><Camera className="w-4 h-4" /> Start camera scanner</>}
        </button>
        {cameraError && <p className="text-xs text-amber-600">{cameraError}</p>}

        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (manual.trim()) {
              verify(manual);
              setManual("");
            }
          }}
          className="flex gap-2"
        >
          <input
            value={manual}
            onChange={(e) => setManual(e.target.value)}
            placeholder="Or type ticket code, e.g. CU-QR-1A2B3C4D-1234"
            aria-label="Ticket code"
            className="flex-1 min-w-0 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2.5 text-sm"
          />
          <button className="px-4 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-bold text-sm">
            Check in
          </button>
        </form>
      </section>

      {/* Result */}
      {result && (
        <div
          role="status"
          className={`rounded-2xl p-4 flex items-start gap-3 border ${
            result.kind === "ok"
              ? "bg-emerald-50 border-emerald-200 text-emerald-900"
              : result.kind === "dup"
              ? "bg-amber-50 border-amber-200 text-amber-900"
              : "bg-red-50 border-red-200 text-red-900"
          }`}
        >
          {result.kind === "ok" ? <CheckCircle2 className="w-6 h-6 shrink-0" /> : result.kind === "dup" ? <AlertTriangle className="w-6 h-6 shrink-0" /> : <XCircle className="w-6 h-6 shrink-0" />}
          <div>
            {result.kind === "bad" ? (
              <div className="font-bold">{result.message}</div>
            ) : (
              <>
                <div className="font-black text-lg">
                  {result.kind === "ok" ? "Welcome in" : "Already checked in"}: {result.rsvp.studentName}
                </div>
                <div className="text-sm">
                  {result.rsvp.studentId} · {result.eventTitle}
                  {result.rsvp.checkedInAt && ` · ${new Date(result.rsvp.checkedInAt).toLocaleTimeString()}`}
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Attendance list */}
      <section className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4">
        <div className="flex items-center justify-between mb-2">
          <h2 className="font-bold text-slate-900 dark:text-white">Attendance</h2>
          <button onClick={refresh} className="text-xs text-campus-600 font-bold flex items-center gap-1">
            <RefreshCw className="w-3 h-3" /> Refresh
          </button>
        </div>
        {forEvent.length === 0 ? (
          <p className="text-sm text-slate-500">No registrations for this event yet.</p>
        ) : (
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">
            {forEvent.map((r) => (
              <li key={r.id} className="py-2 flex items-center justify-between text-sm">
                <span className="text-slate-800 dark:text-slate-200">
                  {r.studentName} <span className="text-slate-400">· {r.studentId}</span>
                </span>
                <span className={r.status === "checked_in" ? "text-emerald-600 font-bold" : "text-slate-400"}>
                  {r.status === "checked_in" ? "Checked in" : "Registered"}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
