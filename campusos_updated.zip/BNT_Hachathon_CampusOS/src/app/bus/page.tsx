"use client";

import React, { useEffect, useMemo, useState } from "react";
import { Bus, Clock, MapPin, CalendarOff, ChevronRight } from "lucide-react";
import { BUS_ROUTES, BUS_OFF_DAYS } from "@/data/busSchedule";

/** Current wall-clock time in Dhaka, independent of the visitor's device timezone. */
function dhakaNow(now: Date) {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Dhaka",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
    weekday: "short",
  }).formatToParts(now);
  const get = (t: string) => parts.find((p) => p.type === t)?.value || "0";
  const weekdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  return {
    h: parseInt(get("hour")) % 24,
    m: parseInt(get("minute")),
    s: parseInt(get("second")),
    day: weekdays.indexOf(get("weekday")),
  };
}

const toMin = (hhmm: string) => {
  const [h, m] = hhmm.split(":").map(Number);
  return h * 60 + m;
};
const fmt12 = (hhmm: string) => {
  const [h, m] = hhmm.split(":").map(Number);
  return `${h % 12 === 0 ? 12 : h % 12}:${String(m).padStart(2, "0")} ${h >= 12 ? "PM" : "AM"}`;
};

export default function BusPage() {
  const [now, setNow] = useState<Date | null>(null);
  const [routeId, setRouteId] = useState(BUS_ROUTES[0].id);

  useEffect(() => {
    setNow(new Date());
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const route = BUS_ROUTES.find((r) => r.id === routeId)!;
  const clock = now ? dhakaNow(now) : null;
  const offToday = clock ? BUS_OFF_DAYS.includes(clock.day) : false;

  const next = useMemo(() => {
    if (!clock || offToday) return null;
    const nowSec = clock.h * 3600 + clock.m * 60 + clock.s;
    return route.departures
      .map((d) => ({ d, diff: toMin(d) * 60 - nowSec }))
      .find((x) => x.diff > 0) || null;
  }, [clock, route, offToday]);

  const countdown = next
    ? {
        h: Math.floor(next.diff / 3600),
        m: Math.floor((next.diff % 3600) / 60),
        s: next.diff % 60,
      }
    : null;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <header>
        <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900 dark:text-white flex items-center gap-2">
          <Bus className="w-7 h-7 text-campus-600" /> Shuttle Bus Finder
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          Pick your route and see when the next bus leaves campus. Times are in Dhaka time.
        </p>
      </header>

      {/* Route picker */}
      <div className="grid grid-cols-3 gap-2 sm:gap-3" role="tablist" aria-label="Bus routes">
        {BUS_ROUTES.map((r) => (
          <button
            key={r.id}
            role="tab"
            aria-selected={r.id === routeId}
            onClick={() => setRouteId(r.id)}
            className={`rounded-2xl border p-3 text-left transition-all ${
              r.id === routeId
                ? "border-campus-500 bg-campus-50 dark:bg-campus-950 ring-2 ring-campus-500/30"
                : "border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-campus-300"
            }`}
          >
            <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400">{r.name}</div>
            <div className="font-black text-slate-900 dark:text-white text-sm sm:text-base">{r.destination}</div>
          </button>
        ))}
      </div>

      {/* Next bus */}
      <section
        aria-live="polite"
        className={`rounded-3xl bg-gradient-to-br ${route.color} text-white p-6 shadow-lg`}
      >
        <div className="flex items-center gap-2 text-white/80 text-sm font-semibold">
          <Clock className="w-4 h-4" /> Next bus to {route.destination}
        </div>
        {!clock ? (
          <div className="mt-3 h-14" />
        ) : offToday ? (
          <div className="mt-3 flex items-center gap-3">
            <CalendarOff className="w-8 h-8" />
            <div className="text-xl font-black">No bus service today</div>
          </div>
        ) : next && countdown ? (
          <>
            <div className="mt-2 text-5xl sm:text-6xl font-black tabular-nums tracking-tight">
              {countdown.h > 0 && `${countdown.h}h `}
              {String(countdown.m).padStart(2, "0")}m {String(countdown.s).padStart(2, "0")}s
            </div>
            <div className="mt-2 text-lg font-bold">Departs at {fmt12(next.d)}</div>
          </>
        ) : (
          <div className="mt-3">
            <div className="text-xl font-black">No more buses today</div>
            <div className="text-white/80 text-sm mt-1">First bus tomorrow: {fmt12(route.departures[0])}</div>
          </div>
        )}
      </section>

      {/* Timetable + stops */}
      <div className="grid md:grid-cols-2 gap-4">
        <section className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5">
          <h2 className="font-bold text-slate-900 dark:text-white mb-3">All departures from campus</h2>
          <ul className="flex flex-wrap gap-2">
            {route.departures.map((d) => {
              const isNext = next?.d === d;
              const passed = clock ? toMin(d) * 60 <= clock.h * 3600 + clock.m * 60 + clock.s : false;
              return (
                <li
                  key={d}
                  className={`px-3 py-2 rounded-xl text-sm font-bold border ${
                    isNext
                      ? "bg-campus-600 text-white border-campus-600"
                      : passed
                      ? "bg-slate-100 dark:bg-slate-800 text-slate-400 border-transparent line-through"
                      : "bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 border-slate-200 dark:border-slate-700"
                  }`}
                >
                  {fmt12(d)}
                </li>
              );
            })}
          </ul>
        </section>

        <section className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5">
          <h2 className="font-bold text-slate-900 dark:text-white mb-3">Stops on {route.name}</h2>
          <ol className="space-y-2">
            {route.stops.map((s, i) => (
              <li key={s} className="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300">
                <MapPin className={`w-4 h-4 ${i === 0 ? "text-campus-600" : "text-slate-400"}`} />
                {s}
                {i < route.stops.length - 1 && <ChevronRight className="w-3 h-3 text-slate-300 ml-auto" />}
              </li>
            ))}
          </ol>
        </section>
      </div>

      <p className="text-xs text-slate-500 dark:text-slate-400">
        Need a different route or time? Ask the Help Desk assistant, for example “next bus to Gulshan”.
      </p>
    </div>
  );
}
