import { MOCK_LOST_AND_FOUND, MOCK_COMPLAINTS, MOCK_EVENTS } from "@/data/mockData";
import { listMerged, upsertItem } from "@/lib/shared";

export interface DatabaseProvider {
  getLostItems(): Promise<any[]>;
  getFoundItems(): Promise<any[]>;
  getComplaints(): Promise<any[]>;
  getEvents(): Promise<any[]>;
  addLostItem(item: any): Promise<void>;
  addFoundItem(item: any): Promise<void>;
  addComplaint(complaint: any): Promise<void>;
  addEvent(event: any): Promise<void>;
}

const idOf = (x: any) => String(x.id ?? x.referenceId ?? Date.now() + Math.random());
const withId = (x: any) => ({ ...x, id: idOf(x) });

/** Shared database (Supabase) with localStorage fallback. Same API the pages already use. */
export const LocalDB: DatabaseProvider = {
  async getLostItems() {
    const seeds = MOCK_LOST_AND_FOUND.filter((i: any) => i.type === "Lost").map(withId);
    return listMerged("lost_items", seeds);
  },
  async getFoundItems() {
    const seeds = MOCK_LOST_AND_FOUND.filter((i: any) => i.type === "Found").map(withId);
    return listMerged("found_items", seeds);
  },
  async getComplaints() {
    return listMerged("complaints", (MOCK_COMPLAINTS as any[]).map(withId));
  },
  async getEvents() {
    return listMerged("events", MOCK_EVENTS as any[]);
  },
  async addLostItem(item) {
    const v = withId(item);
    await upsertItem("lost_items", v.id, v);
  },
  async addFoundItem(item) {
    const v = withId(item);
    await upsertItem("found_items", v.id, v);
  },
  async addComplaint(complaint) {
    const v = withId(complaint);
    await upsertItem("complaints", v.id, v);
  },
  async addEvent(event) {
    const v = withId(event);
    await upsertItem("events", v.id, v);
  },
};
