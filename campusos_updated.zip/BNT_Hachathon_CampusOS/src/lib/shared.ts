/**
 * Shared data layer.
 * - Supabase configured  -> every user sees the same data (table: campus_items)
 * - Supabase missing     -> falls back to this browser's localStorage (local dev only)
 */
import { supabase, isSupabaseConfigured } from "@/lib/supabase/client";

const LS_PREFIX = "campusos_shared_";

function lsRead<T>(collection: string): { id: string; data: T }[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(LS_PREFIX + collection) || "[]");
  } catch {
    return [];
  }
}
function lsWrite<T>(collection: string, rows: { id: string; data: T }[]) {
  try {
    localStorage.setItem(LS_PREFIX + collection, JSON.stringify(rows));
  } catch {}
}

export async function listItems<T = any>(collection: string): Promise<T[]> {
  if (isSupabaseConfigured) {
    const { data, error } = await supabase
      .from("campus_items")
      .select("id,data,created_at")
      .eq("collection", collection)
      .order("created_at", { ascending: false });
    if (!error && data) return data.map((r: any) => r.data as T);
    console.warn("shared.listItems failed, using local cache:", error?.message);
  }
  return lsRead<T>(collection).map((r) => r.data);
}

export async function upsertItem<T = any>(collection: string, id: string, data: T): Promise<boolean> {
  if (isSupabaseConfigured) {
    const { error } = await supabase
      .from("campus_items")
      .upsert({ collection, id, data }, { onConflict: "collection,id" });
    if (!error) return true;
    console.warn("shared.upsertItem failed:", error.message);
  }
  const rows = lsRead<T>(collection).filter((r) => r.id !== id);
  rows.unshift({ id, data });
  lsWrite(collection, rows);
  return !isSupabaseConfigured;
}

export async function removeItem(collection: string, id: string): Promise<void> {
  if (isSupabaseConfigured) {
    const { error } = await supabase.from("campus_items").delete().eq("collection", collection).eq("id", id);
    if (!error) return;
    console.warn("shared.removeItem failed:", error.message);
  }
  lsWrite(collection, lsRead(collection).filter((r) => r.id !== id));
}

/** Seed items (mock data) merged with shared items. Shared item wins on same id. */
export async function listMerged<T extends { id: string }>(collection: string, seeds: T[]): Promise<T[]> {
  const shared = await listItems<T>(collection);
  const ids = new Set(shared.map((s) => s.id));
  return [...shared, ...seeds.filter((s) => !ids.has(s.id))];
}

export const isSharedBackend = isSupabaseConfigured;
