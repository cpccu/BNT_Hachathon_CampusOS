# CampusOS — City University

**One place for everything on campus: events, notes, bus times, lost & found and a helpdesk.**

Built by team **BNT** for the CPCCU AI-Powered Web App Development & Deployment Hackathon 2026.

| | |
|---|---|
| Live app | https://campusos-cityuni.vercel.app |
| Repository | https://github.com/cpccu/BNT_Hachathon_CampusOS |
| Demo video | *(add your Google Drive link here)* |

---

## The problem

Information at City University is spread across 20+ Facebook groups, Messenger chats, ad hoc Google Forms and notice boards. Students miss events, miss shuttles, show up to cancelled classes, can't find past question papers, and lose items with no way to get them back. New students have no map of any of it.

## What CampusOS does

| Module | What a student can do | How it works |
|---|---|---|
| **Club & Event Engine** (`/events`) | Browse one feed of all club events, filter by club/category, search, register, get a QR ticket | Registrations are saved in the shared database per student. Seat counts are the live number of registrations. |
| **QR Check-in** (`/checkin`) | Club leads/admins scan tickets at the door | Camera scanner (or typed code). Each ticket checks in once; a second scan shows "Already checked in". Attendance list updates from the database. |
| **Resource Hub** (`/resources`) | Find past questions and notes by department, course, type; upload new material | Search by course code, title or tag. Uploads (title, course, link) are stored in the shared database and visible to everyone. |
| **Bus Finder** (`/bus`) | Pick a route and see a live countdown to the next shuttle | Times come from `src/data/busSchedule.ts`; the clock always uses Dhaka time. |
| **Lost & Found / Complaints** (`/lost-and-found`) | Post lost or found items, browse what's been reported, file a complaint with a reference number | Posts are shared across all users; search covers name and description. |
| **Help Desk** (`/helpdesk`) | Ask about buses, exams, rules and schedules | Gemini assistant grounded in a City University knowledge base (`src/app/api/chat/route.ts`), plus support tickets and FAQ. |
| **Admin Console** (`/admin`) | Moderate events, manage roles, broadcast alerts | Admin role only. |

## How this helps a real CU student

- **"I only found out about the contest a day late."** Open `/events`: every club's events sit in one list. Register in one tap and keep the QR ticket on your phone.
- **"I missed my shuttle; the timetable was buried in Messenger."** Open `/bus`, choose Route A/B/C, and see the next departure with a countdown. No scrolling through old chats.
- **"I need last semester's CSE 201 questions the night before the exam."** Open `/resources`, type `CSE 201`, and get the shared papers and notes. No messaging five groups.
- **"I lost my ID card."** Post it once on `/lost-and-found`. Anyone who finds it can check "Found" items and contact you; nothing scrolls away in hours.
- **"Nobody hears my complaint."** File it on `/lost-and-found` (Complaints tab) and keep the reference number.
- **"What is the exam grading rule?"** Ask the Help Desk assistant instead of waiting for a group reply.
- **"I'm a first-year student and don't know where anything is."** Everything above is reachable from the one navigation bar.

## Tech stack

Next.js 14 (App Router) · TypeScript · Tailwind CSS · Supabase (Postgres + Auth) · Google Gemini API · `qrcode` (ticket generation) · `html5-qrcode` (door scanner) · Vercel

## Run locally

```bash
git clone https://github.com/cpccu/BNT_Hachathon_CampusOS.git
cd BNT_Hachathon_CampusOS
npm install
cp .env.example .env.local     # then fill in the values (see below)
npm run dev                    # http://localhost:3000
```

### Environment variables

| Variable | Needed for |
|---|---|
| `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Shared data + real accounts. **Without them the app runs in local mode: data is stored only in your own browser.** |
| `GEMINI_API_KEY` | Help Desk assistant. Without it the assistant falls back to built-in answers. |

Never commit `.env.local`. It is listed in `.gitignore`.

### Supabase setup (about 5 minutes)

1. Create a project at supabase.com.
2. SQL Editor → run `supabase/schema.sql`, then `supabase/campusos_shared.sql`.
3. Authentication → Providers → Email: **turn off "Confirm email"** so new students can log in immediately.
4. Copy the project URL and anon key into `.env.local` (and into Vercel → Settings → Environment Variables, then redeploy).

## Demo credentials

Create these accounts once at `/signup` (use the same emails), then log in at `/login`:

| Role | Email | Password |
|---|---|---|
| Student | `student@cityuniversity.edu.bd` | `demo1234` |
| Club lead | `admin@cpccu.edu.bd` | `demo1234` |
| Admin | `admin@cityuniversity.edu.bd` | `admin1234` |

New accounts are students by default. To promote the club lead and admin, run in the Supabase SQL Editor:

```sql
update public.users set role = 'club_admin' where email = 'admin@cpccu.edu.bd';
update public.users set role = 'admin'      where email = 'admin@cityuniversity.edu.bd';
```

Anyone can also register a fresh student account at `/signup`.

### Testing the QR flow (2 minutes)

1. Log in as the student → `/events` → **Register** on any event. A QR ticket opens.
2. Log in as the club lead → `/checkin` → pick the same event → start the camera, or paste the ticket code.
3. The student shows as **Checked in**. Scan again to see **Already checked in**.

## Known limitations (honest list)

- Resource uploads store a link (Drive/OneDrive), not the file itself.
- Lost & Found posts have no photo upload yet.
- Database policies are open for demo purposes. A production version would restrict writes to the signed-in user and move role changes to a server-side check.
- Bus times in `src/data/busSchedule.ts` are sample data until replaced with the transport office timetable.
- The assistant is only as accurate as the knowledge base text in `route.ts`.

## Project structure

```
src/app/            pages: events, checkin, resources, bus, lost-and-found, helpdesk, admin, login, signup, api/chat
src/components/     EventCard, QrTicketModal, Navbar, chatbot widget, ...
src/lib/shared.ts   shared data layer (Supabase table campus_items, localStorage fallback)
src/lib/db.ts       Lost & Found / complaints / events access
src/data/           seed data + bus timetable
supabase/           schema.sql, campusos_shared.sql
```
